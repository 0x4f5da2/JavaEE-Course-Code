create view ly as
  select
    `javaee_exp5_1`.`lytable`.`id`         AS `id`,
    `javaee_exp5_1`.`usertable`.`username` AS `username`,
    `javaee_exp5_1`.`lytable`.`date`       AS `date`,
    `javaee_exp5_1`.`lytable`.`title`      AS `title`,
    `javaee_exp5_1`.`lytable`.`content`    AS `content`,
    `javaee_exp5_1`.`lytable`.`user_id`    AS `user_id`
  from (`javaee_exp5_1`.`lytable`
    join `javaee_exp5_1`.`usertable`)
  where (`javaee_exp5_1`.`lytable`.`user_id` = `javaee_exp5_1`.`usertable`.`id`);

